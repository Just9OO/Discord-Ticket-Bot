// Interaction-level actions shared by slash commands and buttons.
const { MessageFlags, PermissionFlagsBits: P } = require('discord.js');
const config = require('./config');
const { q } = require('./db');
const ui = require('./ui');
const tickets = require('./tickets');

const EPH = MessageFlags.Ephemeral;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const purging = new Set(); // guild ids with a purge in progress

const deny = (i, text) => i.reply({ embeds: [ui.fail(text)], flags: EPH });

async function requireTicket(i) {
  const ticket = i.guildId ? q.ticketByChannel.get(i.channelId) : null;
  if (!ticket) {
    await deny(i, 'This only works inside a ticket channel.');
    return null;
  }
  return ticket;
}

async function requireStaff(i, ticket) {
  if (tickets.isStaff(i, ticket.staff_role_id)) return true;
  await deny(i, 'Only staff can do that.');
  return false;
}

/** Used by /claim and the Claim button. Running it again on your own ticket releases it. */
async function claim(i) {
  const ticket = await requireTicket(i);
  if (!ticket || !(await requireStaff(i, ticket))) return;
  if (ticket.status === 'closed') return deny(i, 'This ticket is closed.');

  const mine = ticket.claimed_by === i.user.id;
  if (ticket.claimed_by && !mine && !i.memberPermissions.has(P.Administrator)) {
    return deny(i, `This ticket is already claimed by <@${ticket.claimed_by}>.`);
  }

  const next = mine ? null : i.user.id;
  q.setClaimed.run(next, ticket.id);

  await i.reply({
    embeds: [
      next
        ? ui.ok(`Ticket claimed by <@${i.user.id}>.`)
        : ui.info(`<@${i.user.id}> released this ticket.`),
    ],
  });
  tickets.refreshWelcome(i.channel, { ...ticket, claimed_by: next }).catch(() => {});
}

/** Used by /close and the Close button's modal. */
async function close(i, reason) {
  const ticket = await requireTicket(i);
  if (!ticket) return;
  if (ticket.status === 'closed') return deny(i, 'This ticket is already closed.');
  if (i.user.id !== ticket.owner_id && !tickets.isStaff(i, ticket.staff_role_id)) {
    return deny(i, 'Only the ticket owner or staff can close this ticket.');
  }

  await i.deferReply(); // building the transcript can take longer than 3 seconds
  const closed = await tickets.closeTicket(i.client, ticket, i.channel, i.user.id, reason);
  await i.editReply({
    embeds: [ui.closedEmbed(closed, i.user.id)],
    components: ui.closedControls(),
  });
  tickets.refreshWelcome(i.channel, closed).catch(() => {});
}

async function reopen(i) {
  const ticket = await requireTicket(i);
  if (!ticket) return;
  if (ticket.status !== 'closed') return deny(i, 'This ticket is not closed.');
  if (i.user.id !== ticket.owner_id && !tickets.isStaff(i, ticket.staff_role_id)) {
    return deny(i, 'Only the ticket owner or staff can reopen this ticket.');
  }

  await i.deferReply();
  const reopened = await tickets.reopenTicket(ticket, i.channel);
  await i.editReply({ embeds: [ui.ok(`Ticket reopened by <@${i.user.id}>.`)] });
  if (i.isButton()) i.message.edit({ components: [] }).catch(() => {});
  tickets.refreshWelcome(i.channel, reopened).catch(() => {});
}

/** /delete and the Delete button. */
async function remove(i) {
  const ticket = await requireTicket(i);
  if (!ticket || !(await requireStaff(i, ticket))) return;

  const seconds = Math.ceil(config.deleteDelayMs / 1000);
  await i.reply({ embeds: [ui.warn(`This ticket will be deleted in ${seconds} seconds…`)] });
  try {
    await tickets.deleteTicket(i.client, ticket, i.channel);
  } catch (err) {
    console.error('[delete]', err);
    await i
      .followUp({ embeds: [ui.fail('I could not delete this channel. Check my **Manage Channels** permission.')] })
      .catch(() => {});
  }
}

async function addUser(i) {
  const ticket = await requireTicket(i);
  if (!ticket || !(await requireStaff(i, ticket))) return;

  const user = i.options.getUser('user', true);
  if (!i.options.getMember('user')) return deny(i, 'That user is not in this server.');
  if (user.bot) return deny(i, 'You cannot add bots to a ticket.');

  const existing = i.channel.permissionOverwrites.cache.get(user.id);
  if (existing?.allow.has(P.ViewChannel)) return deny(i, `<@${user.id}> is already in this ticket.`);

  await tickets.setMemberPerms(
    i.channel,
    user.id,
    Object.fromEntries(tickets.MEMBER_PERMS.map((perm) => [permName(perm), true])),
  );
  await i.reply({
    content: `<@${user.id}>`,
    embeds: [ui.ok(`Added <@${user.id}> to the ticket.`)],
    allowedMentions: { users: [user.id] },
  });
}

async function removeUser(i) {
  const ticket = await requireTicket(i);
  if (!ticket || !(await requireStaff(i, ticket))) return;

  const user = i.options.getUser('user', true);
  if (user.id === ticket.owner_id) return deny(i, 'You cannot remove the ticket owner.');
  if (!i.channel.permissionOverwrites.cache.has(user.id)) {
    return deny(i, `<@${user.id}> was not added to this ticket.`);
  }

  await i.channel.permissionOverwrites.delete(user.id, `Removed by ${i.user.username}`);
  await i.reply({ embeds: [ui.ok(`Removed <@${user.id}> from the ticket.`)] });
}

async function rename(i) {
  const ticket = await requireTicket(i);
  if (!ticket || !(await requireStaff(i, ticket))) return;

  const name = i.options
    .getString('name', true)
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 90);
  if (!name) return deny(i, 'Please use letters or numbers in the name.');

  await i.deferReply();
  const renaming = i.channel.setName(name, `Renamed by ${i.user.username}`).then(() => true);
  renaming.catch(() => {}); // a late failure after the timeout below must not crash the process
  const done = await Promise.race([renaming, sleep(8000).then(() => false)]);

  await i.editReply({
    embeds: [
      done
        ? ui.ok(`Renamed to **#${name}**.`)
        : ui.warn(
            'Discord only allows 2 channel renames per 10 minutes. The new name is queued and ' +
              'will apply automatically.',
          ),
    ],
  });
}

// ---------- close request ----------
/** /close-request: staff ask the opener to confirm the ticket is resolved. */
async function closeRequest(i) {
  const ticket = await requireTicket(i);
  if (!ticket || !(await requireStaff(i, ticket))) return;
  if (ticket.status === 'closed') return deny(i, 'This ticket is already closed.');
  if (i.user.id === ticket.owner_id) return deny(i, 'This is your own ticket. Use /close instead.');

  await i.reply({
    content: `<@${ticket.owner_id}>`,
    embeds: [ui.closeRequestEmbed(i.user.id, i.options.getString('message'))],
    components: ui.closeRequestButtons(),
    allowedMentions: { users: [ticket.owner_id] },
  });
}

/** The opener pressed Yes or No on a close request. */
async function closeRequestAnswer(i, answer) {
  const ticket = q.ticketByChannel.get(i.channelId);
  if (!ticket || ticket.status !== 'open') {
    return i.update({ content: null, embeds: [ui.info('This request is no longer active.')], components: [] });
  }
  if (i.user.id !== ticket.owner_id) return deny(i, 'Only the person who opened the ticket can answer this.');

  if (answer !== 'yes') {
    return i.update({
      content: null,
      embeds: [ui.info(`<@${ticket.owner_id}> says this is **not resolved** yet, so the ticket stays open.`)],
      components: [],
    });
  }

  await i.update({
    content: null,
    embeds: [ui.ok(`<@${ticket.owner_id}> confirmed this is resolved. Closing the ticket…`)],
    components: [],
  });
  const closed = await tickets.closeTicket(
    i.client,
    ticket,
    i.channel,
    i.user.id,
    'Resolved: confirmed by the ticket opener',
  );
  await i.channel.send({
    embeds: [ui.closedEmbed(closed, i.user.id)],
    components: ui.closedControls(),
  });
  tickets.refreshWelcome(i.channel, closed).catch(() => {});
}

// ---------- applications ----------
async function pendingApplication(i) {
  const ticket = await requireTicket(i);
  if (!ticket || !(await requireStaff(i, ticket))) return null;
  if (ticket.kind !== 'application') {
    await deny(i, 'This is not an application.');
    return null;
  }
  if (ticket.app_status !== 'pending') {
    await deny(i, `This application was already ${ticket.app_status}.`);
    return null;
  }
  return ticket;
}

/** Tells the applicant the outcome by DM. Closed DMs are fine: the channel message still pings them. */
async function notifyApplicant(i, ticket, accepted, note) {
  const user = await i.client.users.fetch(ticket.owner_id).catch(() => null);
  await user
    ?.send({
      embeds: [
        ui
          .decisionEmbed(accepted, i.user.id, note)
          .setFooter({ text: i.guild?.name ?? 'Application' }),
      ],
    })
    .catch(() => {});
}

async function applicationDecided(i, ticket, accepted, note) {
  await i.channel.send({
    content: `<@${ticket.owner_id}>`,
    embeds: [ui.decisionEmbed(accepted, i.user.id, note)],
    allowedMentions: { users: [ticket.owner_id] },
  });
  await notifyApplicant(i, ticket, accepted, note);
  tickets.refreshWelcome(i.channel, q.ticketByChannel.get(ticket.channel_id)).catch(() => {});
}

/** Accept button: marks it accepted and grants the topic's role if there is one. */
async function appAccept(i) {
  const ticket = await pendingApplication(i);
  if (!ticket) return;
  await i.deferUpdate();

  const decided = q.setAppStatus.run('accepted', i.user.id, null, ticket.id);
  if (!decided.changes) return;

  let note = null;
  if (ticket.accept_role_id) {
    try {
      const member = await i.guild.members.fetch(ticket.owner_id);
      await member.roles.add(ticket.accept_role_id, `Application #${ticket.number} accepted by ${i.user.username}`);
      note = `Granted <@&${ticket.accept_role_id}>.`;
    } catch (err) {
      console.error('[application] could not grant the role:', err.message);
      note =
        `I could not grant <@&${ticket.accept_role_id}>. Staff: check that I have **Manage Roles** ` +
        'and that my role is above it.';
    }
  }
  await applicationDecided(i, ticket, true, note);
}

/** Deny button: asks staff for an optional reason first. */
async function appDenyPrompt(i) {
  const ticket = await pendingApplication(i);
  if (!ticket) return;
  return i.showModal(ui.denyModal());
}

async function appDenySubmit(i) {
  const ticket = await pendingApplication(i);
  if (!ticket) return;

  const reason = i.fields.getTextInputValue('reason').trim() || null;
  const decided = q.setAppStatus.run('denied', i.user.id, reason, ticket.id);
  if (!decided.changes) return deny(i, 'This application was already reviewed.');

  await i.reply({ embeds: [ui.ok('Application denied.')], flags: EPH });
  await applicationDecided(i, ticket, false, reason);
}

// ---------- /purge ----------
async function purge(i) {
  const scope = i.options.getString('scope') ?? 'closed';
  const rows =
    scope === 'all' ? q.listByGuild.all(i.guildId) : q.listByGuildStatus.all(i.guildId, 'closed');
  if (!rows.length) return i.reply({ embeds: [ui.info(`There are no ${scope} tickets to purge.`)], flags: EPH });

  await i.reply({
    embeds: [
      ui.warn(
        `This will permanently delete **${rows.length}** ${scope} ticket channel(s). ` +
          'Transcripts are **not** generated, and this cannot be undone.',
      ),
    ],
    components: ui.purgeConfirm(i.user.id, scope),
    flags: EPH,
  });
}

async function purgeConfirm(i, answer, userId, scope) {
  if (i.user.id !== userId) return deny(i, 'Only the person who ran /purge can confirm it.');
  if (!i.memberPermissions.has(P.Administrator)) return deny(i, 'Only administrators can purge tickets.');
  if (answer !== 'yes') {
    return i.update({ embeds: [ui.info('Purge cancelled.')], components: [] });
  }
  if (purging.has(i.guildId)) return deny(i, 'A purge is already running in this server.');

  purging.add(i.guildId);
  try {
    const rows =
      scope === 'all' ? q.listByGuild.all(i.guildId) : q.listByGuildStatus.all(i.guildId, 'closed');
    await i.update({ embeds: [ui.warn(`Purging ${rows.length} ticket(s)…`)], components: [] });

    let deleted = 0;
    let failed = 0;
    for (const [index, row] of rows.entries()) {
      try {
        await i.guild.channels.delete(row.channel_id, 'Ticket purge');
        q.deleteById.run(row.id);
        deleted++;
      } catch (err) {
        if (err.code === 10003) {
          q.deleteById.run(row.id); // channel was already gone
          deleted++;
        } else {
          failed++;
        }
      }
      if ((index + 1) % 10 === 0) {
        await i
          .editReply({ embeds: [ui.warn(`Purging… ${index + 1}/${rows.length}`)] })
          .catch(() => {});
      }
    }

    const note = failed ? ` ${failed} could not be deleted (check my **Manage Channels** permission).` : '';
    await i
      .editReply({ embeds: [ui.ok(`Purged **${deleted}** ticket(s).${note}`)] })
      .catch(() => {});
  } finally {
    purging.delete(i.guildId);
  }
}

/** PermissionFlagsBits value -> the key name that permissionOverwrites.edit expects. */
function permName(flag) {
  return Object.keys(P).find((key) => P[key] === flag);
}

module.exports = {
  claim,
  close,
  reopen,
  remove,
  addUser,
  removeUser,
  rename,
  closeRequest,
  closeRequestAnswer,
  appAccept,
  appDenyPrompt,
  appDenySubmit,
  purge,
  purgeConfirm,
};
