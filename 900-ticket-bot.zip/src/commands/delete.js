const { InteractionContextType, SlashCommandBuilder } = require('discord.js');
const actions = require('../actions');

const data = new SlashCommandBuilder()
  .setName('delete')
  .setDescription('Delete this ticket channel (staff only)')
  .setContexts(InteractionContextType.Guild);

module.exports = { data, execute: actions.remove };
