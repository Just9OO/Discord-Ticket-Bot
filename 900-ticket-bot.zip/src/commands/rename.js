const { InteractionContextType, SlashCommandBuilder } = require('discord.js');
const actions = require('../actions');

const data = new SlashCommandBuilder()
  .setName('rename')
  .setDescription('Rename this ticket channel (staff only)')
  .setContexts(InteractionContextType.Guild)
  .addStringOption((o) =>
    o.setName('name').setDescription('New channel name').setRequired(true).setMinLength(1).setMaxLength(90),
  );

module.exports = { data, execute: actions.rename };
