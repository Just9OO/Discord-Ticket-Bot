const {
  ChannelType,
  InteractionContextType,
  MessageFlags,
  PermissionFlagsBits: P,
  SlashCommandBuilder,
} = require('discord.js');
const { db, q } = require('../db');
const ui = require('../ui');
const topicsLib = require('../topics');

const DEFAULT_CATEGORIES = ['General Support', 'Billing', 'Report a Member', 'Other'];
const TEXT_TYPES = [ChannelType.GuildText, ChannelType.GuildAnnouncement];

const data = new SlashCommandBuilder()
  .setName('panel')
  .setDescription('Post a ticket panel members can use to open tickets')
  .setDefaultMemberPermissions(P.ManageGuild)
  .setContexts(InteractionContextType.Guild)
  .addStringOption((o) =>
    o
      .setName('type')
      .setDescription('How members open a ticket')
      .setRequired(true)
      .addChoices(
        { name: 'Click only - a button opens a ticket', value: 'click' },
        { name: 'Form - a button that opens a form to fill in', value: 'form' },
        { name: 'Sidebar - a dropdown menu of categories', value: 'sidebar' },
      ),
  )
  .addChannelOption((o) =>
    o
      .setName('channel')
      .setDescription('Channel to post the panel in')
      .addChannelTypes(...TEXT_TYPES)
      .setRequired(true),
  )
  .addRoleOption((o) =>
    o.setName('staff_role').setDescription('Role that can see and manage tickets').setRequired(true),
  )
  .addStringOption((o) =>
    o
      .setName('message')
      .setDescription('Text of the panel embed (type \\n for a new line)')
      .setRequired(true)
      .setMaxLength(3500),
  )
  .addStringOption((o) =>
    o
      .setName('ticket_message')
      .setDescription('Embed text shown inside every new ticket (type \\n for a new line)')
      .setMaxLength(3500),
  )
  .addBooleanOption((o) =>
    o.setName('claim_button').setDescription('Show a Claim button for staff inside tickets (default: on)'),
  )
  .addChannelOption((o) =>
    o
      .setName('transcript_channel')
      .setDescription('Send a transcript (and ratings) here when a ticket is closed')
      .addChannelTypes(...TEXT_TYPES),
  )
  .addChannelOption((o) =>
    o
      .setName('category')
      .setDescription('Category to create ticket channels in')
      .addChannelTypes(ChannelType.GuildCategory),
  )
  .addStringOption((o) => o.setName('title').setDescription('Panel embed title').setMaxLength(256))
  .addStringOption((o) =>
    o.setName('color').setDescription('Panel embed color as hex, e.g. #5865F2').setMaxLength(7),
  )
  .addStringOption((o) =>
    o
      .setName('label')
      .setDescription('Button text for the first topic (default: Open a Ticket)')
      .setMaxLength(80),
  )
  .addStringOption((o) =>
    o
      .setName('categories')
      .setDescription('Sidebar type: comma-separated dropdown options (max 25)')
      .setMaxLength(1000),
  )
  .addIntegerOption((o) =>
    o
      .setName('max_tickets')
      .setDescription('Open tickets allowed per member in each topic (default: 1)')
      .setMinValue(1)
      .setMaxValue(10),
  )
  .addBooleanOption((o) =>
    o
      .setName('survey')
      .setDescription('DM members a star rating after close; needs a transcript channel (default: on)'),
  )
  .addStringOption((o) =>
    o
      .setName('help_articles')
      .setDescription('When to show knowledge-base articles (default: inside the ticket)')
      .addChoices(
        { name: 'Inside the new ticket', value: 'inside' },
        { name: 'Before the ticket is created', value: 'before' },
        { name: 'Never', value: 'off' },
      ),
  );

const newlines = (text) => text.replace(/\\n/g, '\n');
const fail = (i, text) => i.editReply({ embeds: [ui.fail(text)] });

async function execute(i) {
  await i.deferReply({ flags: MessageFlags.Ephemeral });
  if (!i.memberPermissions.has(P.ManageGuild)) return fail(i, 'You need the **Manage Server** permission.');

  const type = i.options.getString('type', true);
  const channel = i.options.getChannel('channel', true);
  const staffRole = i.options.getRole('staff_role', true);
  const transcriptChannel = i.options.getChannel('transcript_channel');
  const category = i.options.getChannel('category');

  // Colour
  const rawColor = i.options.getString('color');
  let color = null;
  if (rawColor) {
    if (!/^#?[0-9a-f]{6}$/i.test(rawColor)) return fail(i, 'Color must be a hex code like `#5865F2`.');
    color = parseInt(rawColor.replace('#', ''), 16);
  }

  // Labels of the topics this panel starts with: the dropdown options, or one button.
  let labels;
  if (type === 'sidebar') {
    const raw = i.options.getString('categories');
    labels = (raw ? raw.split(',') : DEFAULT_CATEGORIES).map((s) => s.trim()).filter(Boolean);
    if (!labels.length) return fail(i, 'Give at least one dropdown option.');
    labels = labels.slice(0, topicsLib.MAX_TOPICS);
  } else {
    labels = [i.options.getString('label')?.trim() || 'Open a Ticket'];
  }

  // The bot must be able to post the panel, open channels and deliver transcripts.
  const me = await i.guild.members.fetchMe();
  if (!me.permissions.has(P.ManageChannels)) {
    return fail(i, 'I need the **Manage Channels** permission to create ticket channels.');
  }
  const needs = [P.ViewChannel, P.SendMessages, P.EmbedLinks];
  if (!channel.permissionsFor(me).has(needs)) {
    return fail(i, `I cannot send embeds in <#${channel.id}>. I need View Channel, Send Messages and Embed Links there.`);
  }
  if (transcriptChannel && !transcriptChannel.permissionsFor(me).has([...needs, P.AttachFiles])) {
    return fail(i, `I cannot send files in <#${transcriptChannel.id}>. I need View Channel, Send Messages, Embed Links and Attach Files there.`);
  }

  // The panel and its topics are saved together, or not at all.
  const create = db.transaction(() => {
    const inserted = q.insertPanel.run({
      guild_id: i.guildId,
      channel_id: channel.id,
      type,
      staff_role_id: staffRole.id,
      claim_enabled: (i.options.getBoolean('claim_button') ?? true) ? 1 : 0,
      transcript_channel_id: transcriptChannel?.id ?? null,
      category_id: category?.id ?? null,
      ticket_message: newlines(i.options.getString('ticket_message') ?? '') || null,
      options: null,
      max_tickets: i.options.getInteger('max_tickets') ?? 1,
      created_at: Math.floor(Date.now() / 1000),
      survey_enabled: (i.options.getBoolean('survey') ?? true) ? 1 : 0,
      kb_mode: i.options.getString('help_articles') ?? 'inside',
    });
    const id = Number(inserted.lastInsertRowid);
    labels.forEach((label, position) =>
      q.insertTopic.run(topicsLib.newTopic({ panel_id: id, position, label })),
    );
    return id;
  });
  const panelId = create();
  const panel = q.getPanel.get(panelId);

  try {
    const message = await channel.send({
      embeds: [
        ui.panelEmbed({
          title: i.options.getString('title'),
          description: newlines(i.options.getString('message', true)),
          color,
        }),
      ],
      components: ui.panelComponents(panel, topicsLib.forPanel(panelId)),
    });
    q.setPanelMessage.run(message.id, panelId);
  } catch (err) {
    console.error('[panel]', err);
    db.transaction(() => {
      q.deleteTopicsByPanel.run(panelId);
      q.deletePanel.run(panelId);
    })();
    return fail(i, `I could not post the panel in <#${channel.id}>.`);
  }

  return i.editReply({
    embeds: [
      ui.ok(
        `Panel **#${panelId}** posted in <#${channel.id}>.\n` +
          'Add more buttons or dropdown entries, each with its own staff role, category, limit or form, ' +
          `with \`/topic add\`.`,
      ),
    ],
  });
}

module.exports = { data, execute };
