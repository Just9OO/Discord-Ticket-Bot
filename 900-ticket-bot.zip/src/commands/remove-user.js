const { InteractionContextType, SlashCommandBuilder } = require('discord.js');
const actions = require('../actions');

const data = new SlashCommandBuilder()
  .setName('remove-user')
  .setDescription('Remove a member you added to this ticket (staff only)')
  .setContexts(InteractionContextType.Guild)
  .addUserOption((o) => o.setName('user').setDescription('Member to remove').setRequired(true));

module.exports = { data, execute: actions.removeUser };
