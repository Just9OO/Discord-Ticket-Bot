const { InteractionContextType, SlashCommandBuilder } = require('discord.js');
const actions = require('../actions');

const data = new SlashCommandBuilder()
  .setName('add-user')
  .setDescription('Add a member to this ticket (staff only)')
  .setContexts(InteractionContextType.Guild)
  .addUserOption((o) => o.setName('user').setDescription('Member to add').setRequired(true));

module.exports = { data, execute: actions.addUser };
