const {
  InteractionContextType,
  MessageFlags,
  PermissionFlagsBits: P,
  SlashCommandBuilder,
} = require('discord.js');
const actions = require('../actions');
const ui = require('../ui');

const data = new SlashCommandBuilder()
  .setName('purge')
  .setDescription('Delete ticket channels in bulk (Administrator only)')
  .setDefaultMemberPermissions(P.Administrator)
  .setContexts(InteractionContextType.Guild)
  .addStringOption((o) =>
    o
      .setName('scope')
      .setDescription('Which tickets to purge (default: closed)')
      .addChoices(
        { name: 'Closed tickets only', value: 'closed' },
        { name: 'Every ticket, including open ones', value: 'all' },
      ),
  );

module.exports = {
  data,
  async execute(i) {
    // Server owners can change a command's default permissions, so enforce it here too.
    if (!i.memberPermissions.has(P.Administrator)) {
      return i.reply({
        embeds: [ui.fail('Only administrators can purge tickets.')],
        flags: MessageFlags.Ephemeral,
      });
    }
    return actions.purge(i);
  },
};
