const {
  EmbedBuilder,
  InteractionContextType,
  MessageFlags,
  SlashCommandBuilder,
} = require('discord.js');
const { colors } = require('../config');

const data = new SlashCommandBuilder()
  .setName('help')
  .setDescription('Show every ticket command')
  .setContexts(InteractionContextType.Guild);

const embed = new EmbedBuilder()
  .setColor(colors.primary)
  .setTitle('🎫 Ticket Bot • Help')
  .addFields(
    {
      name: 'Setup (Manage Server)',
      value:
        '`/panel` posts a ticket panel with its first button or dropdown.\n' +
        '• **type**: `click` (buttons), `form` (buttons that open a form), `sidebar` (dropdown)\n' +
        '• **message** / **ticket_message**: embed text on the panel / inside each ticket\n' +
        '• **staff_role**, **claim_button**, **transcript_channel**, **category**, **survey**, **help_articles**\n' +
        '`/topic add|edit|remove|list` adds more buttons or dropdown entries to a panel. Each can have its own ' +
        'staff role, category, ticket limit and form, or be an **application**.',
    },
    {
      name: 'Inside a ticket',
      value:
        '`/close [reason]` closes the ticket (owner or staff; works if the button does not)\n' +
        '`/close-request` asks the opener to confirm it is resolved (staff)\n' +
        '`/claim` claims the ticket, run again to release it (staff)\n' +
        '`/add-user` / `/remove-user` manage who can see it (staff)\n' +
        '`/rename` renames the channel (staff)\n' +
        '`/delete` deletes the channel (staff)\n' +
        'Applications get **Accept** and **Deny** buttons for staff.',
    },
    {
      name: 'Help articles',
      value:
        '`/faq` looks up an article (everyone)\n' +
        '`/kb add|remove|list|link|unlink` manages articles (Manage Server)',
    },
    {
      name: 'Admin',
      value: '`/purge [scope]` bulk-deletes ticket channels (Administrator only)',
    },
    { name: 'Other', value: '`/ping` shows latency • `/help` shows this message' },
  );

module.exports = {
  data,
  execute: (i) => i.reply({ embeds: [embed], flags: MessageFlags.Ephemeral }),
};
