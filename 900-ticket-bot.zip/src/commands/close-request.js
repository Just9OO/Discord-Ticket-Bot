const { InteractionContextType, SlashCommandBuilder } = require('discord.js');
const actions = require('../actions');

const data = new SlashCommandBuilder()
  .setName('close-request')
  .setDescription('Ask the ticket opener to confirm their issue is resolved (staff only)')
  .setContexts(InteractionContextType.Guild)
  .addStringOption((o) =>
    o.setName('message').setDescription('Optional note shown to the opener').setMaxLength(1000),
  );

module.exports = { data, execute: actions.closeRequest };
