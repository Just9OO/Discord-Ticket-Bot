const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const { colors } = require('./config');

const DEFAULT_TICKET_TEXT =
  'Thanks for opening a ticket! A member of staff will be with you shortly.\n' +
  'Please describe your issue in as much detail as you can.';
const DEFAULT_APPLICATION_TEXT =
  'Thanks for applying! Your answers are below. A member of staff will review them shortly.';

const pad = (n) => String(n).padStart(4, '0');
const trunc = (s, n) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);
/** Builds a namespaced custom id, e.g. id('t', 3) -> "tk:t:3". */
const id = (...parts) => ['tk', ...parts].join(':');
const stars = (n) => '⭐'.repeat(n) + '☆'.repeat(5 - n);
const kindName = (ticket) => (ticket.kind === 'application' ? 'Application' : 'Ticket');

// ---------- small status embeds ----------
const box = (color, description) => new EmbedBuilder().setColor(color).setDescription(description);
const ok = (text) => box(colors.success, `✅ ${text}`);
const fail = (text) => box(colors.danger, `❌ ${text}`);
const warn = (text) => box(colors.warn, `⚠️ ${text}`);
const info = (text) => box(colors.primary, text);

// ---------- panel ----------
function panelEmbed({ title, description, color }) {
  return new EmbedBuilder()
    .setColor(color ?? colors.primary)
    .setTitle(title || 'Open a Ticket')
    .setDescription(description);
}

const defaultEmoji = (panel, topic) =>
  topic.kind === 'application' ? '📋' : panel.type === 'form' ? '📝' : '🎫';

/**
 * Turns "🎫" or "<:name:123456789012345678>" into the object form Discord's components take.
 * An object is accepted by every discord.js version, unlike a bare string on dropdown options.
 */
function emojiObject(text) {
  const raw = String(text).trim();
  const custom = /^<(a?):(\w{2,32}):(\d{17,20})>$/.exec(raw);
  return custom ? { id: custom[3], name: custom[2], animated: custom[1] === 'a' } : { name: raw };
}

/**
 * A "sidebar" panel is one dropdown of its topics. Every other panel shows one button per topic
 * (up to 25), so a panel with several topics is a multi-panel with no extra setup.
 */
function panelComponents(panel, topics) {
  if (panel.type === 'sidebar') {
    const menu = new StringSelectMenuBuilder()
      .setCustomId(id('tsel', panel.id))
      .setPlaceholder('Select a category to open a ticket…')
      .addOptions(
        topics.map((t) => {
          const option = new StringSelectMenuOptionBuilder()
            .setLabel(trunc(t.label, 100))
            .setValue(String(t.id));
          if (t.description) option.setDescription(trunc(t.description, 100));
          if (t.emoji) option.setEmoji(emojiObject(t.emoji));
          return option;
        }),
      );
    return [new ActionRowBuilder().addComponents(menu)];
  }

  const buttons = topics.map((t) =>
    new ButtonBuilder()
      .setCustomId(id('t', t.id))
      .setLabel(trunc(t.label, 80))
      .setEmoji(emojiObject(t.emoji || defaultEmoji(panel, t)))
      .setStyle(t.kind === 'application' ? ButtonStyle.Success : ButtonStyle.Primary),
  );
  const rows = [];
  for (let i = 0; i < buttons.length; i += 5) {
    rows.push(new ActionRowBuilder().addComponents(buttons.slice(i, i + 5)));
  }
  return rows;
}

/** The form shown before a ticket or application is created. */
function topicModal(topic, questions) {
  const modal = new ModalBuilder().setCustomId(id('tf', topic.id)).setTitle(trunc(topic.label, 45));
  const input = (customId, label, style, max) =>
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId(customId)
        .setLabel(trunc(label, 45))
        .setStyle(style)
        .setRequired(true)
        .setMaxLength(max),
    );

  if (questions.length) {
    // 900 characters x 5 answers still fits inside one embed (6000 characters in total).
    modal.addComponents(
      ...questions.map((question, index) =>
        input(`q${index}`, question, TextInputStyle.Paragraph, 900),
      ),
    );
  } else {
    modal.addComponents(
      input('subject', 'Subject', TextInputStyle.Short, 100),
      input('details', 'How can we help?', TextInputStyle.Paragraph, 1000),
    );
  }
  return modal;
}

// ---------- inside a ticket ----------
function welcomeEmbed(ticket, { text, fields = [] } = {}) {
  const embed = new EmbedBuilder()
    .setColor(colors.primary)
    .setTitle(`${kindName(ticket)} #${pad(ticket.number)}`)
    .setDescription(
      text || (ticket.kind === 'application' ? DEFAULT_APPLICATION_TEXT : DEFAULT_TICKET_TEXT),
    )
    .addFields({ name: 'Opened by', value: `<@${ticket.owner_id}>`, inline: true });

  if (ticket.subject) {
    embed.addFields({ name: 'Topic', value: trunc(ticket.subject, 1024), inline: true });
  }
  for (const f of fields.slice(0, 20)) {
    embed.addFields({ name: trunc(f.name, 256), value: trunc(f.value || '—', 1024) });
  }
  return embed.setTimestamp();
}

/**
 * Close, plus Claim/Release when enabled. A pending application also gets Accept and Deny.
 */
function controls(ticket) {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(id('close'))
      .setLabel('Close')
      .setEmoji('🔒')
      .setStyle(ButtonStyle.Danger),
  );
  if (ticket.claim_enabled) {
    const claimed = Boolean(ticket.claimed_by);
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(id('claim'))
        .setLabel(claimed ? 'Release' : 'Claim')
        .setEmoji(claimed ? '🔓' : '🙋')
        .setStyle(claimed ? ButtonStyle.Secondary : ButtonStyle.Success),
    );
  }
  const rows = [row];

  if (ticket.kind === 'application' && ticket.app_status === 'pending') {
    rows.push(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(id('app', 'accept'))
          .setLabel('Accept')
          .setEmoji('✅')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId(id('app', 'deny'))
          .setLabel('Deny')
          .setEmoji('✖️')
          .setStyle(ButtonStyle.Danger),
      ),
    );
  }
  return rows;
}

function closeModal() {
  return new ModalBuilder()
    .setCustomId(id('closesub'))
    .setTitle('Close ticket')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('reason')
          .setLabel('Reason (optional)')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(false)
          .setMaxLength(512),
      ),
    );
}

function closedEmbed(ticket, closerId) {
  let text = `Closed by <@${closerId}>.`;
  if (ticket.close_reason) text += `\n**Reason:** ${trunc(ticket.close_reason, 1000)}`;
  return new EmbedBuilder()
    .setColor(colors.danger)
    .setTitle(`${kindName(ticket)} #${pad(ticket.number)} closed`)
    .setDescription(text)
    .setFooter({ text: 'Reopen or delete this ticket with the buttons below.' })
    .setTimestamp();
}

function closedControls() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(id('reopen'))
        .setLabel('Reopen')
        .setEmoji('🔓')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(id('delete'))
        .setLabel('Delete')
        .setEmoji('🗑️')
        .setStyle(ButtonStyle.Danger),
    ),
  ];
}

function purgeConfirm(userId, scope) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(id('purge', 'yes', userId, scope))
        .setLabel('Purge')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(id('purge', 'no', userId, scope))
        .setLabel('Cancel')
        .setStyle(ButtonStyle.Secondary),
    ),
  ];
}

// ---------- close request ----------
function closeRequestEmbed(staffId, message) {
  let text = `<@${staffId}> thinks this ticket is resolved.`;
  if (message) text += `\n\n> ${trunc(message, 1000).replace(/\n/g, '\n> ')}`;
  return new EmbedBuilder()
    .setColor(colors.warn)
    .setTitle('Is your issue resolved?')
    .setDescription(text)
    .setFooter({ text: 'Only the person who opened the ticket can answer.' });
}

function closeRequestButtons() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(id('crq', 'yes'))
        .setLabel('Yes, close it')
        .setEmoji('✅')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(id('crq', 'no'))
        .setLabel('No, keep it open')
        .setEmoji('❌')
        .setStyle(ButtonStyle.Danger),
    ),
  ];
}

// ---------- applications ----------
function decisionEmbed(accepted, staffId, note) {
  const embed = new EmbedBuilder()
    .setColor(accepted ? colors.success : colors.danger)
    .setTitle(accepted ? 'Application accepted' : 'Application denied')
    .setDescription(`${accepted ? 'Accepted' : 'Denied'} by <@${staffId}>.`);
  if (note) embed.addFields({ name: accepted ? 'Note' : 'Reason', value: trunc(note, 1024) });
  return embed.setTimestamp();
}

function denyModal() {
  return new ModalBuilder()
    .setCustomId(id('appdeny'))
    .setTitle('Deny application')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('reason')
          .setLabel('Reason (sent to the applicant)')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(false)
          .setMaxLength(500),
      ),
    );
}

// ---------- rating survey ----------
function surveyEmbed(survey, guildName) {
  return new EmbedBuilder()
    .setColor(colors.primary)
    .setTitle('How was your support?')
    .setDescription(
      `Your ticket **#${pad(survey.ticket_number)}** in **${trunc(guildName, 100)}** was closed.\n` +
        'Tap a star to rate the help you received.',
    );
}

function surveyButtons(surveyId) {
  return [
    new ActionRowBuilder().addComponents(
      [1, 2, 3, 4, 5].map((n) =>
        new ButtonBuilder()
          .setCustomId(id('rate', surveyId, n))
          .setLabel(String(n))
          .setEmoji('⭐')
          .setStyle(ButtonStyle.Secondary),
      ),
    ),
  ];
}

function rateModal(surveyId, n) {
  return new ModalBuilder()
    .setCustomId(id('ratesub', surveyId, n))
    .setTitle(`Your rating: ${n} / 5`)
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('comment')
          .setLabel('Anything you want to add? (optional)')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(false)
          .setMaxLength(500),
      ),
    );
}

function ratedEmbed(rating) {
  return new EmbedBuilder()
    .setColor(colors.success)
    .setTitle('Thanks for your feedback!')
    .setDescription(`You rated this ticket **${stars(rating)}**`);
}

function feedbackEmbed(survey, rating, comment, guildName) {
  const embed = new EmbedBuilder()
    .setColor(rating >= 4 ? colors.success : rating === 3 ? colors.warn : colors.danger)
    .setTitle(`Ticket #${pad(survey.ticket_number)} rated ${rating}/5`)
    .setDescription(stars(rating))
    .addFields(
      { name: 'From', value: `<@${survey.owner_id}>`, inline: true },
      {
        name: 'Handled by',
        value: survey.claimed_by ? `<@${survey.claimed_by}>` : 'Unclaimed',
        inline: true,
      },
    )
    .setFooter({ text: guildName })
    .setTimestamp();
  if (survey.subject) embed.addFields({ name: 'Topic', value: trunc(survey.subject, 1024) });
  if (comment) embed.addFields({ name: 'Comment', value: trunc(comment, 1024) });
  return embed;
}

// ---------- knowledge base ----------
function kbEmbed(article) {
  return new EmbedBuilder()
    .setColor(colors.neutral)
    .setTitle(trunc(article.title, 256))
    .setDescription(trunc(article.body, 4000))
    .setFooter({ text: `Help article #${article.id}` });
}

const kbIntroEmbed = () =>
  info('📚 **These articles might help while you wait.** If one solves it, you can close the ticket.');

function kbGateButtons(token) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(id('kbdone', token))
        .setLabel('That solved it')
        .setEmoji('✅')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(id('kbgo', token))
        .setLabel('Open a ticket anyway')
        .setEmoji('🎫')
        .setStyle(ButtonStyle.Secondary),
    ),
  ];
}

function kbAddModal() {
  const field = (customId, label, style, required, max, placeholder) =>
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId(customId)
        .setLabel(label)
        .setStyle(style)
        .setRequired(required)
        .setMaxLength(max)
        .setPlaceholder(placeholder),
    );
  return new ModalBuilder()
    .setCustomId(id('kbadd'))
    .setTitle('New help article')
    .addComponents(
      field('title', 'Title', TextInputStyle.Short, true, 100, 'How do I get a refund?'),
      field(
        'keywords',
        'Keywords (comma separated)',
        TextInputStyle.Short,
        false,
        200,
        'refund, money back, payment',
      ),
      field('body', 'Answer', TextInputStyle.Paragraph, true, 4000, 'Write the answer members will see…'),
    );
}

module.exports = {
  pad,
  trunc,
  id,
  stars,
  ok,
  fail,
  warn,
  info,
  panelEmbed,
  panelComponents,
  topicModal,
  welcomeEmbed,
  controls,
  closeModal,
  closedEmbed,
  closedControls,
  purgeConfirm,
  closeRequestEmbed,
  closeRequestButtons,
  decisionEmbed,
  denyModal,
  surveyEmbed,
  surveyButtons,
  rateModal,
  ratedEmbed,
  feedbackEmbed,
  kbEmbed,
  kbIntroEmbed,
  kbGateButtons,
  kbAddModal,
};
