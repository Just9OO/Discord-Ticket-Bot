// A topic is one button or dropdown entry on a panel. Any setting left empty on a topic
// falls back to the panel's, so a plain panel works with zero per-topic configuration.
const { q } = require('./db');

const MAX_QUESTIONS = 5; // a Discord modal holds at most 5 inputs
const MAX_QUESTION_LENGTH = 45; // ...and each input label at most 45 characters
const MAX_TOPICS = 25; // one dropdown, or five rows of five buttons

/** The custom questions of a topic, or [] when it has none. */
function questionsOf(topic) {
  if (!topic?.questions) return [];
  try {
    const parsed = JSON.parse(topic.questions);
    return Array.isArray(parsed)
      ? parsed.map(String).filter(Boolean).slice(0, MAX_QUESTIONS)
      : [];
  } catch {
    return [];
  }
}

/** Parses "Question one | Question two" typed into a slash command option. */
function parseQuestions(raw) {
  const questions = String(raw ?? '')
    .split('|')
    .map((s) => s.trim())
    .filter(Boolean);
  if (questions.length > MAX_QUESTIONS) {
    return { error: `You can ask at most ${MAX_QUESTIONS} questions.` };
  }
  const tooLong = questions.find((s) => s.length > MAX_QUESTION_LENGTH);
  if (tooLong) {
    return {
      error: `Each question can be at most ${MAX_QUESTION_LENGTH} characters (Discord's limit for form labels). Shorten: "${tooLong}"`,
    };
  }
  return { questions };
}

// A unicode emoji, or a custom one like <:name:123456789012345678>
const EMOJI = /^(?:<a?:\w{2,32}:\d{17,20}>|\p{Extended_Pictographic}(?:️|‍\p{Extended_Pictographic}|\p{Emoji_Modifier})*)$/u;
const isEmoji = (text) => EMOJI.test(String(text).trim());

/** Effective settings for a ticket opened from `topic` on `panel`. */
function resolve(panel, topic) {
  return {
    kind: topic?.kind ?? 'ticket',
    staffRoleId: topic?.staff_role_id ?? panel.staff_role_id,
    parentId: topic?.category_id ?? panel.category_id ?? null,
    transcriptChannelId: topic?.transcript_channel_id ?? panel.transcript_channel_id ?? null,
    maxTickets: topic?.max_tickets ?? panel.max_tickets,
    message: topic?.ticket_message ?? panel.ticket_message ?? null,
    acceptRoleId: topic?.accept_role_id ?? null,
  };
}

/** Whether clicking this topic must show a form before anything is created. */
function needsForm(panel, topic) {
  return (
    topic.kind === 'application' || questionsOf(topic).length > 0 || panel.type === 'form'
  );
}

/** A full row for insertTopic: callers pass only what they care about. */
function newTopic(fields) {
  return {
    position: 0,
    emoji: null,
    description: null,
    kind: 'ticket',
    staff_role_id: null,
    category_id: null,
    transcript_channel_id: null,
    max_tickets: null,
    questions: null,
    ticket_message: null,
    accept_role_id: null,
    ...fields,
  };
}

const forPanel = (panelId) => q.topicsByPanel.all(panelId);

module.exports = {
  MAX_QUESTIONS,
  MAX_QUESTION_LENGTH,
  MAX_TOPICS,
  questionsOf,
  parseQuestions,
  isEmoji,
  resolve,
  needsForm,
  newTopic,
  forPanel,
};
